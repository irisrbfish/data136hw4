"""
ASGI config for cloudysky project.
"""

import os

from django.core.asgi import get_asgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'cloudysky.settings')

application = get_asgi_application() 